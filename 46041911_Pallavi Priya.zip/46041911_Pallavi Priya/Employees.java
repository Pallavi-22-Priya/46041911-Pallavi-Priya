package l5;

import java.util.Scanner;

public class Employees {
	public void checkSal(float salary) throws EmployeeException
	{
		if(salary<3000)
		{
			throw new EmployeeException("Not a valid salary");
		}
		else {
			System.out.println(salary);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the salary:");
		float salary=sc.nextFloat();
		Employees employees=new Employees();
		try {
			employees.checkSal(salary);
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
		sc.close();

	}

}
