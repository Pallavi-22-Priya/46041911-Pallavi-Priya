package ab;
import java.util.*;
public class Dup2 {
public static void main(String[] args)
	{
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter length of array ");
	 int n=sc.nextInt();
	 System.out.println("Enter array elements");
	 int a[]=new int[6];
	 for(int i=0;i<n;i++)
	  {
	  a[i]=sc.nextInt();
	  }
	 Dup2 lab=new Dup2();
	 lab.removeDuplicates(a,n);
	}


	        public  void removeDuplicates(int a[],int n)
	        {
	       
	        for(int i=0;i<n-1;i++)
	        {
	        for(int j=i+1;j<n;j++)
	        {
	        if(a[i]==a[j])
	        {
	        System.out.println("The duplicate elements are  "+a[j]);
	        }
	        }
	        }
	        for(int i=0;i<n;i++)
	        {
	        for(int j=i+1;j<n;j++)
	        {
	        if(a[i]<a[j])
	        {
	        int temp=a[i];
	        a[i]=a[j];
	        a[j]=temp;
	        }
	        }
	        }
	        System.out.println("Descending order ");
	        for(int i=0;i<n;i++)
	        {
	        System.out.println("   "+a[i]);
	        }
	        }
	}



