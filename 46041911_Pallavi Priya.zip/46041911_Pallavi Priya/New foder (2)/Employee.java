package ab;

public class Employee {
private int ID;
private String name;
private float salary;
private String designation;
private String insuranceScheme;
public int getID() {
return ID;
}
public void setID(int iD) {
this.ID = iD;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public float getSalary() {
return salary;
}
public float setSalary(float salary) {
return this.salary = salary;
}
public String getDesignation() {
return designation;
}
public void setDesignation(String designation) {
this.designation = designation;
}
public String getInsuranceScheme() {
return insuranceScheme;
}
public void setInsuranceScheme(String insuranceScheme) {
this.insuranceScheme = insuranceScheme;
}
/*@Override
public String toString() {
return "EmpInsuranceSystem [ID=" + ID + ", name=" + name + ", salary=" + salary + ", designation=" + designation
+ ", insuranceScheme=" + insuranceScheme + "]";*/


}


