package ab;

public interface Employeeservices {

}
