package ab;


public class Service extends Employee implements EmployeeService
	{
	int id;
	float sal;
	String name,desg;
	Employee emp=new Employee();


	public static void main(String[] args)
	{
	Service s =new Service();
	s.details();
	s.display();
	}
	@Override
	public void details()
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter empid");
	id=sc.nextInt();
	emp.setID(id);
	System.out.println("Enter emp name");
	name=sc.next();
	emp.setName(name);
	System.out.println("Enter emp designation");
	desg=sc.next();
	emp.setDesignation(desg);
	System.out.println("Enter emp salary");
	sal=sc.nextFloat();
	emp.setSalary(sal);
	sc.close();
	}
}
