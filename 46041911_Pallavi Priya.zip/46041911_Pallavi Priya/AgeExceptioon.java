package l5;

import java.util.Scanner;
class AgeException extends Exception {
	String s;
	public AgeException(String s)
	{
		this.s=s;
	}
	public String toString()
	{
		return "Exception occured"+s;
	}
}


class AgeExceptioon
{
	
	public void checkAge(int age)throws Exception
	{
		if( age<=15)
		{
			throw new AgeException("Please enter the valid age");
		}
		else
		{
			System.out.println("valid age");
		
		}
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the age:");
		int age=sc.nextInt();
		AgeExceptioon a=new AgeExceptioon();
		
		try {
				a.checkAge(age);
			}
		
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		sc.close();
		
	}
}