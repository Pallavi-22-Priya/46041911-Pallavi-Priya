package l5;
import java.util.*;

public class Employee {
	public void checkName(String f_Name,String l_Name) throws EmployeeExe
	{	
		
		if((f_Name==null) && (l_Name==null))
		{
			throw new EmployeeExe("Please enter the name firstname and last name");
		}
		else
		{
			System.out.println(f_Name+l_Name);
			
		}
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the fullname:");
		String f_Name=sc.next();
		System.out.println("Enter the lastname:");
		String l_Name=sc.next();
		Employee e=new Employee();
		try {
			e.checkName(f_Name, l_Name);
		}
		catch(EmployeeExe ex)
		{
			System.out.println(ex);
		}
		sc.close();
	}

}
