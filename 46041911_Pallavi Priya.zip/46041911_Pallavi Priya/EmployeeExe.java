package l5;

class EmployeeExe extends Exception
{
	public EmployeeExe(String name)
	{
		super(name);
	}
}