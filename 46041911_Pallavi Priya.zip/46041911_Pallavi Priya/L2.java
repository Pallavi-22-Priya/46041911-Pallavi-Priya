package bb;
public class L2 {

	int getSecondSmallest(int []a)
	{
		int n = 0;
		int i;
		 
		for( i=0;i<=n;i++)
		{
			for(int j=i+1;j<=n;j++)
			{
				if(a[i]<a[j])
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
	return a[1];
	
	}





	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,2,3,4};
		L2 l2=new L2();
		System.out.println(l2.getSecondSmallest(a));

	}

}
