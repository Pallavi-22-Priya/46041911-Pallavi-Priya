package bb;
import java.util.*;

public class Token {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		int sum=0;
		System.out.println("Enter the integer:");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		StringTokenizer obj  =new StringTokenizer(s);
		while(obj.hasMoreTokens())
		{
			 String temp=obj.nextToken();
			num=Integer.parseInt(temp);
			System.out.println(num);
			sum=sum+num;
		}
		System.out.println(sum);
		

	}

}
