package bb;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Labss {


public static void main(String[] args) {

Labss lb=new Labss();
Scanner sc=new Scanner(System.in);
System.out.println("Enter size of array: ");
int n=sc.nextInt();
int arr[] =new int[6];
System.out.println("Enter array elements: ");
for(int i=0;i<n;i++)
{
arr[i]=sc.nextInt();
}
	L2 lab=new L2();
	int number=lab.getSecondSmallest(arr);
System.out.println(number);

}
public void getSecondSmallest(int arr[],int n)
{
ArrayList<Integer> al=new ArrayList<Integer>();

Collections.sort(al);
}

}
}
