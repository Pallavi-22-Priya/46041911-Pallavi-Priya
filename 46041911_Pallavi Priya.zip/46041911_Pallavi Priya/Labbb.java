package bb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Labbb {
	  public static void main(String[] args)

      {

                     Scanner sc=new Scanner(System.in);

                       int a[]=new int[] {12,10,6,51};

                       System.out.println("Enter array values");

            for (int i = 0; i < 4; i++) { 

               a[i]=sc.nextInt();

                }

                     Labbb lb=new Labbb();

                     lb.getSorted(a);

                    

      }



      public void getSorted(int a[])

      {

                     HashMap<Integer, Integer> hmt  = new HashMap<Integer, Integer>();

                      hmt.put(23, 45);

                      hmt.put(47, 9);

                      hmt.put(26, 29);

                      Collection<Integer> values = hmt.values();

                     ArrayList<Integer> listOfValues = new ArrayList<Integer>(values);

                     Collections.sort(listOfValues);

                     System.out.println("The Values of the Map are "+ listOfValues);

                     for (Integer value : listOfValues)

                     {

                    	 System.out.println(value);

                     }

                    

      }

}