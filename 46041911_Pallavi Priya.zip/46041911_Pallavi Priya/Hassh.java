package bb;
import java.util.*;

public class Hassh {
public static void main(String[] args)
{
	
			 HashMap <Integer,String> Student=new HashMap<>();
			 Student.put(1, "pallavi");
			 Student.put(3, "priya");
			 Student.put(2, "priya");
			 Student.put(4, "priyas");
			 System.out.println(Student);
		
			
			ArrayList<String> S1=new ArrayList<>();
			S1.add("pallavi");
			S1.add("sfg");
			S1.add("priya");
			S1.add("priyas");
			
			System.out.println(S1);
			Collections.sort(S1);
			System.out.println(S1);
		}
}

