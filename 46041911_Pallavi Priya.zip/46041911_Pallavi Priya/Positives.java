package bb;

import java.util.*;
public class Positives 
{
	public boolean validate(String s)
	{
		char c[]=s.toCharArray();
		int i,n,f=1;
		n=c.length;
		for(i=0;i<n-1;i++)
		{
			if(c[i]<c[i+1])
				f++;
		}
		if(f==n)
			return true;
		else
			return false;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your string");
		String s=sc.next();
		Positives p=new Positives();
		if(p.validate(s))
			System.out.println("the string is positive");
		else
			System.out.println("the string is not positive");
	}
}