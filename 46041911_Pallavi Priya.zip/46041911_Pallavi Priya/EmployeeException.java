package l5;

@SuppressWarnings("serial")
public class EmployeeException  extends Exception{
	public  EmployeeException(String s)
	{
		super(s);
	}

}
